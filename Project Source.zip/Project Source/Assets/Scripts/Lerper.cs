﻿
using UnityEngine;
using System;

public class Lerper<T>
{
    public Lerper(Func<T> getSubject, Action<T, T, float> lerpAction)
    {
        GetSubject = getSubject;
        LerpAction = lerpAction;
    }


    #region  public properties
    public bool IsEnable { get; private set; } = false;
    public float Duration { get; set; } = 1.0f;
    #endregion


    #region private properties
    Func<T> GetSubject { get; }
    Action<T, T, float> LerpAction { get; }
    #endregion


    #region private fields
    T a, b;
    float finishTime;
    #endregion


    #region public methods
    public void Begin(in T a, in T b)
    {
        IsEnable = true;
        finishTime = Time.time + Duration;
        this.a = a;
        this.b = b;
    }

    public void Begin(in T b)
        => Begin(GetSubject(), b);

    public void Stop()
        => IsEnable = false;

    public bool TryUpdate()
    {
        if (!IsEnable)
            return false;

        if (Time.time > finishTime)
        {
            LerpAction(a, b, 1.0f);
            IsEnable = false;
        }
        else
        {
            float t = 1.0f - (finishTime - Time.time) / Duration;
            LerpAction(a, b, t);
        }
        return true;
    }
    #endregion
}

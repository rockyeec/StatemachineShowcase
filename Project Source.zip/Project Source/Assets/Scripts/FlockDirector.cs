using UnityEngine;
using System.Collections.Generic;
using System;

public class FlockDirector : MonoBehaviour
{
    [Header("Flocking Parameters")]
    [SerializeField] float size = 1.0f;
    [SerializeField] float neighbourRadius = 6.0f;

    [Header("Flocking Influence Parameters")]
    [SerializeField] float separateMultiplier = 1.0f;
    [SerializeField] float alignMultiplier = 1.0f;
    [SerializeField] float cohesionMultiplier = 1.0f;

    readonly static List<Vehicle> boids = new List<Vehicle>();

    public static event Action<Vector3> OnSteeringForceCalculated = delegate { }; 
    public static void Add(Vehicle vehicle) => boids.Add(vehicle);
    public static void Remove(Vehicle vehicle) => boids.Remove(vehicle);

    void Update()
    {
        foreach (var item in boids)
        {
            Vector3 steeringForce = GetSteeringForce(item);
            OnSteeringForceCalculated(steeringForce);
        }
    }

    Vector3 GetSteeringForce(Vehicle boid)
    {
        float distancingRadius = size * 2.0f;
        Vector3 sumSeparate = Vector3.zero;
        Vector3 sumAlign = Vector3.zero;
        Vector3 sumCohere = Vector3.zero;
        int countSeparate = 0;
        int countAlignAndCohere = 0;

        foreach (var other in boids)
        {
            if (other == boid) continue;

            float distance = Vector3.Distance(boid.Position, other.Position);

            if (distance > 0.0f)
            {
                if (distance < distancingRadius)
                {
                    Vector3 offset = boid.Position - other.Position;
                    Vector3 direction = offset.normalized;

                    Vector3 separation = direction / distance;

                    sumSeparate += separation;
                    ++countSeparate;
                }
                if (distance < neighbourRadius)
                {
                    sumAlign += other.Velocity;
                    sumCohere += other.Position;
                    ++countAlignAndCohere;
                }
            }
        }

        Vector3 steeringForce = Vector3.zero;
        if (countSeparate > 0)
        {
            Vector3 desiredVelocity = boid.MaxSpeed * (sumSeparate / countSeparate).normalized;
            Vector3 steer = desiredVelocity - boid.Velocity;
            steeringForce += (separateMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
        }
        if (countAlignAndCohere > 0)
        {
            {
                Vector3 alignVelocity = sumAlign / countAlignAndCohere;
                Vector3 desiredVelocity = boid.MaxSpeed * alignVelocity.normalized;
                Vector3 steer = desiredVelocity - boid.Velocity;
                steeringForce += (alignMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
            }

            {
                Vector3 averagePosition = sumCohere / countAlignAndCohere;
                Vector3 desiredDirection = averagePosition - boid.Position;
                Vector3 desiredVelocity = boid.MaxSpeed * desiredDirection.normalized;
                Vector3 steer = desiredVelocity - boid.Velocity;
                steeringForce += (cohesionMultiplier * Vector3.ClampMagnitude(steer, boid.MaxForce));
            }
        }

        return steeringForce;
    }
}
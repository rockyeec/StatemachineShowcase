using UnityEngine;

public class PlasticBag : Food
{
    protected override void Update()
    {
        base.Update();

        transform.position += 0.069f * Vector3.up * Time.deltaTime;
        if (transform.position.y > CameraUtil.WorldRect.yMax)
            ObjectPool.PoolIn(this);
    }
}

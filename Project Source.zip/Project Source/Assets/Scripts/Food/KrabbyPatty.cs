using UnityEngine;

public class KrabbyPatty : Food
{
    public override void Init()
    {
        base.Init();

        QuickSfx.KrabbyPatty();
    }

    protected override void Update()
    {
        base.Update();

        transform.Rotate(Vector3.forward, Time.deltaTime * 69.0f);
        transform.Translate(Vector3.down * Time.deltaTime * 0.069f, Space.World);

        if (transform.position.y < CameraUtil.WorldRect.yMin)
            ObjectPool.PoolIn(this);
    }
}

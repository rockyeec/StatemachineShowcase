﻿using UnityEngine;
using Random = UnityEngine.Random;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(CircleCollider2D))]
public class Food : Poolable
{
    public bool IsEaten { get; private set; } = false;

    [SerializeField] float baseHungerReplenishment = 10.0f;
    [SerializeField] float scaleFactor = 0.1f;

    float hungerReplenishment;
    Collider2D Collider { get; set; }

    Lerper<Vector3> scaleLerper;

    private void Reset() => gameObject.layer = 8;

    protected virtual void Awake()
    {
        Collider = GetComponent<Collider2D>();

        scaleLerper = new Lerper<Vector3>(
            () => transform.localScale,
            (a, b, t) => transform.localScale = Vector3.LerpUnclamped(a, b, t.SmootherStep()))
        { Duration = 0.3f };       
    }

    protected virtual void Update()
    {
        bool isLerping = scaleLerper.TryUpdate();
        if (IsEaten && !isLerping)
        {
            ObjectPool.PoolIn(this);
        }
    }

    public override void Init()
    {
        base.Init();

        float delta = 0.5f * baseHungerReplenishment;
        hungerReplenishment = Random.Range(-delta, delta) + baseHungerReplenishment;
        Vector3 scale = hungerReplenishment * scaleFactor * Vector3.one;
        scaleLerper.Begin(2.0f * scale, scale);
        
        IsEaten = false;
        Collider.enabled = true;
    }

    public bool GetEaten(Hunger hunger)
    {
        if (IsEaten)
            return false;

        IsEaten = true;
        Collider.enabled = false;

        hunger.CurrentValue += hungerReplenishment;

        scaleLerper.Begin(Vector3.one * 0.0f);
        return true;
    }
}

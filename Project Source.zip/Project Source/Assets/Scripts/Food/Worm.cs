using UnityEngine;

public class Worm : Food
{
    [SerializeField] Vehicle vehicle = null;
    [SerializeField] WanderState.Stats wanderStats = null;
    StateMachine StateMachine { get; } = new StateMachine();

    protected override void Awake()
    {
        base.Awake();

        vehicle.Init(transform);
        var material = GetComponent<SpriteRenderer>().material;
        StateMachine.SetState(new WanderState(vehicle, new LocomotionAnimator(vehicle, material), wanderStats));
    }

    protected override void Update()
    {
        base.Update();

        StateMachine.Tick(Time.deltaTime);
    }

    public override void Init()
    {
        base.Init();

        QuickSfx.Woohoo();
    }
}

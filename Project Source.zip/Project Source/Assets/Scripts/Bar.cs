﻿using UnityEngine;

public class Bar : MonoBehaviour
{
    Material material;
    float velocity;

    public float FillAmount { get; set; }

    float SmoothFillAmount
    {
        get => material.GetFloat(UniformIDs.FillAmount);
        set => material.SetFloat(UniformIDs.FillAmount, value);
    }

    private void Awake()
    {
        if (material == null)
        {
            var renderer = GetComponent<Renderer>();
            if (renderer != null)
            {
                material = renderer.material;
            }
        }
        if (material == null)
            Debug.LogError($"Bar Material for {name} is not Assigned!");

        BarController.OnShowBar += ShowBar;
    }
    private void OnDestroy()
    {
        BarController.OnShowBar -= ShowBar;
    }

    void ShowBar(bool b) => gameObject.SetActive(b);

    private void OnEnable()
    {
        gameObject.SetActive(BarController.IsShow);
        SmoothFillAmount = FillAmount;
    }
    private void Update()
    {
        SmoothFillAmount = Mathf.SmoothDamp(SmoothFillAmount, FillAmount, ref velocity, 0.15f);
    }
}

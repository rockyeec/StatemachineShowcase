﻿using UnityEngine;

public static class UniformIDs
{
    // Fish
    public static int WiggleSpeed     { get; } = Shader.PropertyToID("_WiggleSpeed");
    public static int TimeOffset      { get; } = Shader.PropertyToID("_TimeOffset");
    public static int FlipY           { get; } = Shader.PropertyToID("_FlipY");
    public static int YawDot          { get; } = Shader.PropertyToID("_YawDot");
    public static int WiggleAmount    { get; } = Shader.PropertyToID("_WiggleAmount");
    public static int WiggleFrequency { get; } = Shader.PropertyToID("_WiggleFrequency");

    // Stomach
    public static int FillAmount { get; } = Shader.PropertyToID("_FillAmount");

    // Shockwave
    public static int Radius { get; } = Shader.PropertyToID("_Radius");

    // Post processing
    public static int BlurTex { get; } = Shader.PropertyToID("_BlurTex");
}

﻿using UnityEngine;

[ExecuteInEditMode]
public class ScreenEffect : MonoBehaviour
{
    [SerializeField] Material waterMaterial = null;
    [SerializeField] Material highpassMaterial = null;
    [SerializeField] Material blurMaterial = null;
    [SerializeField] Material bloomMaterial = null;

    [Range(0, 8)]
    [SerializeField] int iterations = 3;

    [Range(0, 5)]
    [SerializeField] int downRes = 3;

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        int width = source.width >> downRes;
        int height = source.height >> downRes;

        var wateredSource = RenderTexture.GetTemporary(source.width, source.height);
        Graphics.Blit(source, wateredSource, waterMaterial);

        var tempTex = RenderTexture.GetTemporary(width, height);
        Graphics.Blit(wateredSource, tempTex, highpassMaterial);

        for (int i = 0; i < iterations; i++)
        {
            tempTex.filterMode = FilterMode.Bilinear;
            var tempTex2 = RenderTexture.GetTemporary(width, height);
            Graphics.Blit(tempTex, tempTex2, blurMaterial);
            RenderTexture.ReleaseTemporary(tempTex);
            tempTex = tempTex2;
        }        

        bloomMaterial.SetTexture(UniformIDs.BlurTex, tempTex);
        Graphics.Blit(wateredSource, destination, bloomMaterial);
        RenderTexture.ReleaseTemporary(wateredSource);
        RenderTexture.ReleaseTemporary(tempTex);
    }
}
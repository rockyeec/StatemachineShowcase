using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class ShockwaveCamera : MonoBehaviour
{
    [SerializeField]
    Camera cam = null;

    [SerializeField]
    [Range(0, 5)]
    int downRes = 2;

    static int CameraTex { get; } = Shader.PropertyToID("_ShockwaveTex");

    private void Awake()
    {
        if (cam == null)
            cam = GetComponent<Camera>();

        if (cam.targetTexture != null)
        {
            RenderTexture temp = cam.targetTexture;
            cam.targetTexture = null;
            DestroyImmediate(temp);
        }

        cam.targetTexture = new RenderTexture(cam.pixelWidth >> downRes, cam.pixelHeight >> downRes, 16)
        { filterMode = FilterMode.Bilinear };

        Shader.SetGlobalTexture(CameraTex, cam.targetTexture);
    }
}

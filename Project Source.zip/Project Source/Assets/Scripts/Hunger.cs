﻿using UnityEngine;
using System;

[Serializable]
public class Hunger
{
    [SerializeField] float maximumValue = 10.0f;
    [SerializeField] float depletionRate = 1.0f;
    [SerializeField] Bar bar = null;

    public Hunger() => Init();
    public bool IsHungry => PercentValue < 0.5f;
    public bool IsStarving => PercentValue < 0.2f;
    public float PercentValue { get; private set; }
    public float CurrentValue
    {
        get => currentValue;
        set
        {
            currentValue = Mathf.Clamp(value, 0.0f, maximumValue);
            PercentValue = currentValue / maximumValue;

            if (bar != null)
                bar.FillAmount = PercentValue;
        }
    }
    float currentValue;

    public void Init()
        => CurrentValue = maximumValue;

    public void Tick(in float deltaTime)
    {
        CurrentValue -= depletionRate * deltaTime;
    }
}
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class Shockwave : Poolable
{
    Material material;

    Lerper<float> radiusLerper;

    float Radius
    {
        get => material.GetFloat(UniformIDs.Radius);
        set => material.SetFloat(UniformIDs.Radius, value);
    }

    private void Awake()
    {
        material = GetComponent<SpriteRenderer>().material;
        radiusLerper = new Lerper<float>(
            () => Radius, 
            (a, b, t) => Radius = Mathf.LerpUnclamped(a, b, t))
        { Duration = 0.69f };
    }

    public override void Init()
    {
        base.Init();
        radiusLerper.Begin(0.0f, 1.0f);
    }
    private void Update()
    {
        if (!radiusLerper.TryUpdate())
            ObjectPool.PoolIn(this);
    }
}

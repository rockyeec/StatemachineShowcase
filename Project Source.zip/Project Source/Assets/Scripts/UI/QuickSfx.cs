using UnityEngine;

public class QuickSfx : MonoBehaviour
{
    [SerializeField] AudioSource audioSource = null;

    [Header("Audio Clips")]
    [SerializeField] AudioClip[] taps = null;
    [SerializeField] AudioClip woohoo = null;
    [SerializeField] AudioClip[] slurps = null;
    [SerializeField] AudioClip krabbyPatty = null;

    static QuickSfx Instance { get; set; }

    private void Awake()
    {
        Instance = this;
    }

    public static void Tap() => Instance.audioSource.PlayOneShot(Instance.taps.GetRandom());
    public static void Woohoo() => Instance.audioSource.PlayOneShot(Instance.woohoo);
    public static void Slurp() => Instance.audioSource.PlayOneShot(Instance.slurps.GetRandom());
    public static void KrabbyPatty() => Instance.audioSource.PlayOneShot(Instance.krabbyPatty);
    public static void Play(AudioClip audioClip, float voulmePercent = 1.0f) => Instance.audioSource.PlayOneShot(audioClip, Instance.audioSource.volume * voulmePercent);
}
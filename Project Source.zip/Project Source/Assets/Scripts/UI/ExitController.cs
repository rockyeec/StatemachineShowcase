using UnityEngine;

public class ExitController : MonoBehaviour
{
    public void Exit()
    {
        Application.Quit();
    }
}

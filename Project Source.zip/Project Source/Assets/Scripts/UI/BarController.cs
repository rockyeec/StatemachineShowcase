using UnityEngine;
using System;

public class BarController : MonoBehaviour
{
    public static event Action<bool> OnShowBar = delegate { };
    public static bool IsShow { get; private set; } = true;
    public void ToggleShow(bool isShow)
    {
        IsShow = isShow;
        OnShowBar(isShow);
    }
}

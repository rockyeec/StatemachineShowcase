﻿using System.Collections.Generic;
using UnityEngine;

public class FishSpawner : MonoBehaviour
{
    [SerializeField] string[] fishPrefabNames = null;
    readonly List<int> fishIDs = new List<int>();

    int shockwave;

    private void Start()
    {
        for (int i = 0; i < fishPrefabNames.Length; i++)
        {
            fishIDs.Add(ObjectPool.StringToHash(fishPrefabNames[i]));
        }
        SpawnFish();

        shockwave = ObjectPool.StringToHash("Shockwave");
    }
    public void SpawnFish()
    {        
        var fish = ObjectPool.PoolOut(fishIDs.GetRandom(), Vector3.zero, Quaternion.identity);
        fish.transform.Rotate(Vector3.forward, Random.value * 360.0f);

        try
        {
            ObjectPool.PoolOut(shockwave, Vector3.zero, Quaternion.identity);
        }
        catch { }
    }
}

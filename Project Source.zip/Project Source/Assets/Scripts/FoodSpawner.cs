﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class FoodSpawner : MonoBehaviour
{
    [SerializeField] string[] foodPrefabNames = null;
    [SerializeField] int currentFoodIndex = 0;
    [SerializeField] Image image = null;
    [SerializeField] TextMeshProUGUI text = null;
    int[] foodIDs;
    Sprite[] sprites;
    private void Awake()
    {
        int length = foodPrefabNames.Length;
        foodIDs = new int[ length ];
        sprites = new Sprite[ length ];
        for (int i = 0; i < length; i++)
        {
            foodIDs[i] = ObjectPool.StringToHash(foodPrefabNames[i]);

            var poolable = ObjectPool.Peek(foodIDs[i]);
            var spriteRenderer = poolable.GetComponent<SpriteRenderer>();
            if (spriteRenderer)
            {
                sprites[i] = spriteRenderer.sprite;
            }
        }
        UpdateFood();
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (!EventSystem.current.IsPointerOverGameObject())
            {
                Vector3 worldPosition = CameraUtil.MouseWorldPosition;
                Poolable wormObject = ObjectPool.PoolOut(foodIDs[currentFoodIndex], worldPosition, Quaternion.identity);
                wormObject.transform.Rotate(Vector3.forward, Random.value * 360.0f);
            }
        }

        float scroll = Input.GetAxisRaw("Mouse ScrollWheel");

        if (scroll > 0)
        {
            currentFoodIndex.Increment(foodIDs.Length);
            UpdateFood();
        }
        else if (scroll < 0)
        {
            currentFoodIndex.Decrement(foodIDs.Length);
            UpdateFood();
        }
    }

    void UpdateFood()
    {
        image.sprite = sprites[currentFoodIndex];
        text.text = foodPrefabNames[currentFoodIndex];
    }
}

﻿using System.Collections.Generic;
using UnityEngine;

public static class FoodFinder
{
    static readonly int foodLayer = 8;
    static readonly int maxFoodDetectedCount = 69;
    static readonly Collider2D[] foodColliders = new Collider2D[maxFoodDetectedCount];
    static readonly List<Collider2D> detectedFoods = new List<Collider2D>();
    public static Food Get(in Vector3 position, in float detectionRadius)
    {
        int length = Physics2D.OverlapCircleNonAlloc(position, detectionRadius, foodColliders, 1 << foodLayer);
        if (length > 0)
        {
            detectedFoods.Clear();
            for (int i = 0; i < length; i++)
                detectedFoods.Add(foodColliders[i]);
            var foodCollider = detectedFoods.GetNearest(position);
            return foodCollider.GetComponent<Food>();
        }
        return null;
    }
}

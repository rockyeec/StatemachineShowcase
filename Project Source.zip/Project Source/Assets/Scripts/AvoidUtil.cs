﻿using UnityEngine;

public static class AvoidUtil
{
    class RayDirections
    {
        public int Count 
            => Directions.Length;
        public Vector3 this[int index]
            => Directions[index];
        public RayDirections()
        {
            int count = 8;

            int segmentCount = count - 1;
            float segmentRadians = Mathf.PI / (float)segmentCount;
            float startRadian = Mathf.PI * 0.5f;

            Directions = new Vector3[count];
            for (int i = 0; i < count; i++)
            {
                float currentRadian = startRadian + i * segmentRadians;
                Directions[i] = new Vector3( Mathf.Cos(currentRadian), Mathf.Sin(currentRadian), 0.0f );
            }
        }       
        public Vector3[] Directions { get; }
    }

    readonly static RayDirections rayDirections = new RayDirections();
    readonly static LayerMask wallLayer = 1 << 0;
    readonly static RaycastHit2D[] hits = new RaycastHit2D[1];

    public static void DebugDrawAll( Vector3 position , Quaternion rotation )
    {
        foreach (Vector3 dir in rayDirections.Directions)
        {
            Debug.DrawRay(position, rotation * dir);
        }
    }

    public static Vector3 GetHeading( Vector3 position, Quaternion rotation, float rayDistance = 0.69f )
    {
        Vector3 total = Vector3.zero;

        foreach (Vector3 dir in rayDirections.Directions)
        {
            Vector3 localDir = rotation * dir;
            int hitsCount = Physics2D.RaycastNonAlloc(position, localDir, hits, rayDistance, wallLayer);

            float distance = hitsCount != 0
                ? hits[0].distance * 0.25f
                : rayDistance;

            total += distance * localDir;
        }

        Vector3 heading = total.normalized;
        bool isForward = Vector3.Dot(heading, rotation * Vector3.left) > 0.99f;

        return isForward ? Vector3.zero : heading;
    }
}
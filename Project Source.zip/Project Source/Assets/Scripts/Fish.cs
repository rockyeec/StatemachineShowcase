﻿using UnityEngine;
using Random = UnityEngine.Random;

[SelectionBase]
[RequireComponent(typeof(SpriteRenderer))]
public class Fish : Poolable
{
    [SerializeField] Vehicle vehicle = null;
    [SerializeField] WanderState.Stats wanderStats = null;
    [SerializeField] ArriveState.Stats arriveStats = null;
    [SerializeField] Hunger hunger = null;

    FishParentState parentStateMachine;

    private void Awake()
    {
        vehicle.Init(transform);

        var material = GetComponent<SpriteRenderer>().material;

        var animator = new LocomotionAnimator(vehicle, material);

        parentStateMachine = new FishParentState(this, vehicle, animator, hunger, wanderStats, arriveStats);
    }
    private void Update()
    {
        parentStateMachine.Tick(Time.deltaTime);

#if UNITY_EDITOR
        AvoidUtil.DebugDrawAll(transform.position, transform.rotation);
        Debug.DrawRay(transform.position, AvoidUtil.GetHeading(transform.position, transform.rotation), Color.red);
#endif
    }

    public override void Init()
    {
        base.Init();
        hunger.Init();
        parentStateMachine.Init();
    }
}

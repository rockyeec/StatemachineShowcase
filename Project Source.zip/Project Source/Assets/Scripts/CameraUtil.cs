﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static  class CameraUtil
{
    static Camera camera;
    public static Camera Camera
    {
        get
        {
            if (camera == null)
            {
                camera = Camera.main;
            }
            return camera;
        }
    }

    public static Rect WorldRect
    { 
        get
        {
            float v = Camera.orthographicSize;
            float h = Camera.orthographicSize * Camera.aspect;

            return new Rect(-h, -v, h * 2.0f, v * 2.0f);
        }
    }

    public static Vector3 MouseWorldPosition
        => Camera.ScreenToWorldPoint(Input.mousePosition).With(z: 0.0f);

}

using UnityEngine;

public class AquariumTapper : MonoBehaviour
{
    static int shockwave;
    private void Awake()
    {
        shockwave = ObjectPool.StringToHash("Shockwave");
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Vector3 worldPosition = CameraUtil.MouseWorldPosition;
            ObjectPool.PoolOut(shockwave, worldPosition, Quaternion.identity);
            QuickSfx.Tap();
        }
    }
}

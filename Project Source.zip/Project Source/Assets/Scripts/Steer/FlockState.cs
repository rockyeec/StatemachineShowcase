using UnityEngine;

public class FlockState : SteerState
{
    readonly float wanderWeight = 0.1f;
    WanderState.Stats WanderStats { get; }
    Vector3 steeringForce = Vector3.left;
    float nextTime;

    public FlockState(Vehicle vehicle, LocomotionAnimator animator, WanderState.Stats wanderStats)
        :
        base(vehicle, animator, 0.025f)
    {
        WanderStats = wanderStats;

        FlockDirector.OnSteeringForceCalculated += SetSteeringForce;

        Vector2 randomDir = Random.insideUnitCircle.normalized;
        Vehicle.Velocity = randomDir * Vehicle.MaxSpeed;
    }
    ~FlockState() => FlockDirector.OnSteeringForceCalculated -= SetSteeringForce;
    void SetSteeringForce(Vector3 v) => steeringForce = v;
    public override void OnEnter()
    {
        FlockDirector.Add(Vehicle);
        base.OnEnter();
    }
    protected override void Tick(in float deltaTime, out Vector3 steeringForce)
    {
        steeringForce = this.steeringForce + wanderWeight * WanderUtil.GetSteeringForce(ref nextTime, WanderStats, Vehicle);
    }
    public override void OnExit()
    {
        FlockDirector.Remove(Vehicle);
        base.OnExit();
    }
}

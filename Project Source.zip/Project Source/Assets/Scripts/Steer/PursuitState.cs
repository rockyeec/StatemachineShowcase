using UnityEngine;

public class PursuitState : SteerState
{
    Vector3 targetPositionLastFrame;

    public PursuitState(Vehicle vehicle, LocomotionAnimator animator)
        :
        base(vehicle, animator, 1.0f)
    { }

    protected override void Tick(in float deltaTime, out Vector3 steeringForce)
    {
        Vector3 targetOffset = Vehicle.Target - Vehicle.Position;
        Vector3 targetDirection = targetOffset.normalized;

        Vector3 targetFrameOffset = Vehicle.Target - targetPositionLastFrame;
        Vector3 approximatedTargetVelocity = targetFrameOffset / Mathf.Max(1e-5f, deltaTime);
        Vector3 targetMoveDirection = approximatedTargetVelocity.normalized;

        float dot = Vector3.Dot(targetDirection, targetMoveDirection);
        Vector3 predictedTargetPosition = Vehicle.Target;
        if (dot >= 0.0f)
            predictedTargetPosition += approximatedTargetVelocity * CalculateEstimationTime(targetOffset);

        Vector3 predictedTargetOffset = (predictedTargetPosition - Vehicle.Position);
        Vector3 predictedTargetDirection = predictedTargetOffset.normalized;

        Vector3 desiredVelocity = predictedTargetDirection * Vehicle.MaxSpeed;

        // Cache for next frame
        targetPositionLastFrame = Vehicle.Target;

        steeringForce = VehicleUtility.GetSteeringForce(Vehicle, desiredVelocity);
    }
    private float CalculateEstimationTime(Vector3 targetOffset)
    {
        return targetOffset.sqrMagnitude / (Vehicle.MaxSpeed * Vehicle.MaxSpeed);
    }
}
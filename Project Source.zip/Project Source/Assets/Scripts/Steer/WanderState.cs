using UnityEngine;
using Random = UnityEngine.Random;



public class WanderState : SteerState
{
    [System.Serializable]
    public class Stats
    {
        public float WanderDecisionInterval => wanderDecisionInterval;
        public float WanderRadius => wanderRadius;
        public float WanderDistanceAhead => wanderDistanceAhead;

        [SerializeField] float wanderDecisionInterval = 1.0f;
        [SerializeField] float wanderRadius = 1.0f;
        [SerializeField] float wanderDistanceAhead = 1.0f;
    }

    Stats WanderStats { get; }
    float nextTime = 0.0f;

    public WanderState(Vehicle vehicle, LocomotionAnimator animator, Stats wanderStats)
        :
        base(vehicle, animator)
    {
        WanderStats = wanderStats;
    }
    public override void OnEnter()
    {
        nextTime = 0.0f;
        base.OnEnter();
    }
    protected override void Tick(in float deltaTime, out Vector3 steeringForce)
    {
        //if (Time.time >= nextTime)
        //{
        //    nextTime = Time.time + WanderStats.WanderDecisionInterval;
        //
        //    Vector3 forwardPosition = Vehicle.Position + (Vehicle.Rotation * Vector3.left * WanderStats.WanderDistanceAhead);
        //    Vector2 randomInsideCircle = Random.insideUnitCircle.normalized * WanderStats.WanderRadius;
        //    Vector3 targetPosition = forwardPosition + (Vector3)randomInsideCircle;
        //
        //    //Debug.DrawLine(forwardPosition, targetPosition, Color.red, ICanWander.WanderDecisionInterval);
        //    //Debug.DrawLine(Vehicle.Position, forwardPosition, Color.green, ICanWander.WanderDecisionInterval);
        //    //Debug.DrawLine(Vehicle.Position, targetPosition, Color.blue, ICanWander.WanderDecisionInterval);
        //
        //    Vehicle.Target = currentTargetLocation = targetPosition;
        //}
        //
        //Vector3 targetOffset = currentTargetLocation - Vehicle.Position;
        //Vector3 targetDirection = targetOffset.normalized;
        //Vector3 desiredVelocity =  Vehicle.MaxSpeed* targetDirection;
        //
        //steeringForce = VehicleUtility.GetSteeringForce(Vehicle, desiredVelocity);
        steeringForce = WanderUtil.GetSteeringForce(ref nextTime, WanderStats, Vehicle);
    }
}

public static class WanderUtil
{
    public static Vector3 GetSteeringForce(ref float nextTime, in WanderState.Stats wanderStats, Vehicle vehicle)
    {
        if (Time.time >= nextTime)
        {
            nextTime = Time.time + wanderStats.WanderDecisionInterval;

            Vector3 forwardPosition = vehicle.Position + (vehicle.Rotation * Vector3.left * wanderStats.WanderDistanceAhead);
            Vector2 randomInsideCircle = Random.insideUnitCircle.normalized * wanderStats.WanderRadius;
            Vector3 targetPosition = forwardPosition + (Vector3)randomInsideCircle;

            vehicle.Target = targetPosition;
        }

        Vector3 targetOffset = vehicle.Target - vehicle.Position;
        Vector3 targetDirection = targetOffset.normalized;
        Vector3 desiredVelocity = vehicle.MaxSpeed * targetDirection;

        return VehicleUtility.GetSteeringForce(vehicle, desiredVelocity);
    }
}
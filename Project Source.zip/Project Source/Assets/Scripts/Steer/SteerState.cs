using UnityEngine;

public abstract class SteerState : IState
{
    protected Vehicle Vehicle { get; }
    LocomotionAnimator Animator { get;}
    float Weight { get; }

    public SteerState(Vehicle vehicle, LocomotionAnimator animator, float weight = 0.0f)
    {
        Vehicle = vehicle;
        Animator = animator;
        Weight = weight;
    }

    public virtual void OnEnter()
    {
    }

    public virtual void OnExit()
    {
    }

    public void Tick(in float deltaTime)
    { 
        Tick(deltaTime, out Vector3 steeringForce);

        // Do avoid wall
        Vector3 avoidWallDirection = AvoidUtil.GetHeading(Vehicle.Position, Vehicle.Rotation);
        Vector3 avoidWallDesiredVelocity = avoidWallDirection * Vehicle.MaxSpeed;
        Vector3 avoidWallSteeringForce = VehicleUtility.GetSteeringForce(Vehicle, avoidWallDesiredVelocity);

        avoidWallSteeringForce = Vector3.LerpUnclamped(avoidWallSteeringForce, steeringForce, Weight);
        steeringForce = Vector3.LerpUnclamped(steeringForce, avoidWallSteeringForce, avoidWallDirection.sqrMagnitude);

        VehicleUtility.UpdateFromSteeringForce(Vehicle, steeringForce, deltaTime);        

        Animator.Tick();

        VehicleUtility.CheckBounds(Vehicle);
    }
    abstract protected void Tick(in float deltaTime, out Vector3 steeringForce);
}

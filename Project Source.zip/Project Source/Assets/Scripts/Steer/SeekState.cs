using UnityEngine;

public class SeekState : SteerState
{
    public SeekState(Vehicle vehicle, LocomotionAnimator animator)
        :
        base(vehicle, animator, 1.0f)
    { }

    protected override void Tick(in float deltaTime, out Vector3 steeringForce)
    {
        Vector3 desiredVelocity = (Vehicle.Target - Vehicle.Position).normalized * Vehicle.MaxSpeed;
        steeringForce = VehicleUtility.GetSteeringForce(Vehicle, desiredVelocity);
    }
}
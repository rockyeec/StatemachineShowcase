using UnityEngine;



public class ArriveState : SteerState
{
    [System.Serializable]
    public class Stats
    {
        public float ArriveRadius => arriveRadius;
        [SerializeField] float arriveRadius = 1.0f;
    }

    Stats ArriveStats { get; }

    public ArriveState(Vehicle vehicle, LocomotionAnimator animator, Stats stats)
        :
        base(vehicle, animator, 1.0f)
    {
        ArriveStats = stats;
    }

    protected override void Tick(in float deltaTime, out Vector3 steeringForce)
    {
        Vector3 targetOffset = Vehicle.Target - Vehicle.Position;
        float distance = Mathf.Max(1e-3f, targetOffset.magnitude);
        float rampedSpeed = Vehicle.MaxSpeed * (distance / ArriveStats.ArriveRadius);
        float clippedSpeed = Mathf.Min(rampedSpeed, Vehicle.MaxSpeed);
        Vector3 desiredVelocity = (clippedSpeed / distance) * targetOffset;

        steeringForce = VehicleUtility.GetSteeringForce(Vehicle, desiredVelocity);
    }
}

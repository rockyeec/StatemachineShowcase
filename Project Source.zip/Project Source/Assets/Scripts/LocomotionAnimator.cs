﻿using UnityEngine;

public class LocomotionAnimator
{
    protected Vehicle Vehicle { get; }
    public Material Material { get; }
    Lerper<float> FlipLerper { get; }

    float FlipY
    {
        get => Material.GetFloat(UniformIDs.FlipY);
        set => Material.SetFloat(UniformIDs.FlipY, value);
    }

    float WiggleSpeed
    {
        get => Material.GetFloat(UniformIDs.WiggleSpeed);
        set => Material.SetFloat(UniformIDs.WiggleSpeed, value);
    }

    float dot = 1.0f;
    float wiggleSpeedVel;

    public LocomotionAnimator(Vehicle vehicle, Material material)
    {
        Vehicle = vehicle;
        Material = material;

        FlipLerper = new Lerper<float>(
            () => FlipY, 
            (a, b, t) => FlipY = Mathf.LerpUnclamped(a, b, t.SmootherStep())
            )
        { Duration = 0.420f };

        material.SetFloat(UniformIDs.TimeOffset, Random.value * 6.9f);
    }

    public void Tick()
    {
        UpdateFlipY();
        UpdateWiggleSpeed();
    }

    private void UpdateWiggleSpeed()
    {
        WiggleSpeed = Mathf.SmoothDamp(WiggleSpeed, Vehicle.Velocity.magnitude, ref wiggleSpeedVel, 0.1f);
    }

    private void UpdateFlipY()
    {
        float previousDot = dot;
        dot = Vector3.Dot(Vehicle.Rotation * Vector3.left, Vector3.left);
        bool hasFlipped = Mathf.Sign(dot) != Mathf.Sign(previousDot);
        if (hasFlipped)
        {
            FlipLerper.Begin(Mathf.Sign(dot));     
        }
        FlipLerper.TryUpdate();
    }
}

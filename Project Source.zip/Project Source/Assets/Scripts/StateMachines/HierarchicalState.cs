﻿using System.Collections.Generic;
using System.Linq;

public abstract class HierarchicalState : IState
{
    Dictionary<string, StateMachine> Layers { get; } = new Dictionary<string, StateMachine>();
    protected StateMachine BaseLayer => Layers.FirstOrDefault().Value;

    protected HierarchicalState()
        => Layers.Add("Base Layer", new StateMachine());

    protected StateMachine AddLayer(string name)
    {
        StateMachine stateMachine = new StateMachine();
        Layers.Add(name, stateMachine);
        return stateMachine;
    }
    protected StateMachine GetLayer(string name)
        => Layers[name];

    public virtual void OnEnter()
    {
        foreach (var item in Layers)
        {
            item.Value.Enter();
        }
    }

    public virtual void OnExit()
    {
        foreach (var item in Layers)
        {
            item.Value.Exit();
        }
    }

    public virtual void Tick(in float deltaTime)
    {
        foreach (var item in Layers)
        {
            item.Value.Tick(deltaTime);
        }
    }
}
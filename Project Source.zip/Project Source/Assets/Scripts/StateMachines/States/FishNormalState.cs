using UnityEngine;
using System;

public class FishNormalState : HierarchicalState
{
    Action ToDefaultState { get; }

    Food worm;

    public FishNormalState(Vehicle vehicle, LocomotionAnimator animator, WanderState.Stats wanderStats, Hunger hunger, ArriveState.Stats arriveStats)
    {
        // all layers
        StateMachine baseLayer = BaseLayer;
        StateMachine lookForFoodLayer = AddLayer("Look For Food Layer");

        // all states
        var flockState = new FlockState(vehicle, animator, wanderStats);
        var chaseFoodState = new ChaseFoodState(vehicle, animator, hunger, () => worm, arriveStats);
        var eatFoodState = new EatFoodState(0.69f, animator);
        var lookForFoodState = new LookForFoodState(vehicle, value => worm = value);
        var emptyState = EmptyState.Instance;

        // all transitions
        baseLayer.AddTransition(flockState, chaseFoodState, () => !IsWormDead() && hunger.IsHungry);
        baseLayer.AddTransition(chaseFoodState, flockState, IsWormDead);
        baseLayer.AddTransition(chaseFoodState, eatFoodState, HasEaten);
        baseLayer.AddTransition(eatFoodState, flockState, () => eatFoodState.IsFinish);
        lookForFoodLayer.AddTransition(emptyState, lookForFoodState, () => hunger.IsHungry && IsWormDead());
        lookForFoodLayer.AddTransition(lookForFoodState, emptyState, () => !(hunger.IsHungry && IsWormDead()));

        // reset function
        ToDefaultState = () =>
        {
            baseLayer.SetState(flockState);
            lookForFoodLayer.SetState(emptyState);
        };

        // all defaults
        ToDefaultState();

        // all local methods
        bool HasEaten()
        {
            bool isReach = (vehicle.Target - vehicle.Position).IsShorterThan(0.2f);
            if (isReach)
                if (worm.GetEaten(hunger))
                    return true;
            return false;
        }

        bool IsWormDead()
        {
            if (worm != null)
                if (!worm.IsEaten)
                    return false;
            return true;
        }
    }

    public override void OnEnter()
    {
        ToDefaultState();
        base.OnEnter();
    }
}

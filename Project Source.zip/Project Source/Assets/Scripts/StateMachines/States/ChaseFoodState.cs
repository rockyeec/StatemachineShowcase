﻿using System;
using UnityEngine;

public class ChaseFoodState : HierarchicalState
{
    Vehicle Vehicle { get; }
    Func<Food> GetWorm { get; }

    public ChaseFoodState(Vehicle vehicle, LocomotionAnimator animator, Hunger hunger, Func<Food> getWorm, ArriveState.Stats arriveStats)
    {
        Vehicle = vehicle;
        GetWorm = getWorm;

        StateMachine baseLayer = BaseLayer;

        var arriveState = new ArriveState(vehicle, animator, arriveStats);
        var fastArriveState = new FastArriveState(vehicle, animator/*, arriveStats*/);

        baseLayer.AddTransition(arriveState, fastArriveState, () => hunger.IsStarving);
        baseLayer.AddTransition(fastArriveState, arriveState, () => !hunger.IsStarving);
        baseLayer.SetState(arriveState);
    }

    public override void OnEnter()
    {
        UpdateTarget();
        base.OnEnter();
    }

    public override void Tick(in float deltaTime)
    {
        UpdateTarget();
        base.Tick(deltaTime);
    }

    void UpdateTarget()
    {
        if (GetWorm() != null)
            Vehicle.Target = GetWorm().transform.position;
    }
}

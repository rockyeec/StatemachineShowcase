
using UnityEngine;

public class FishAliveState : HierarchicalState
{
    public FishAliveState(Vehicle vehicle, LocomotionAnimator material, Hunger hunger, WanderState.Stats wanderStats, ArriveState.Stats arriveStats)
    {
        StateMachine baseLayer = BaseLayer;

        var fishNormalState = new FishNormalState(vehicle, material, wanderStats, hunger, arriveStats);
        var fishFleeState = new FishFleeState(vehicle, material);

        baseLayer.AddTransition(fishFleeState, fishNormalState, () => fishFleeState.IsFinish);
        baseLayer.AddTransition(fishNormalState, fishFleeState, () => fishFleeState.IsTap);

        baseLayer.SetState(fishNormalState);
    }
}

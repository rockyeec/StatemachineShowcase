﻿using UnityEngine;
using System;

public class FishParentState : HierarchicalState
{
    public Action Init { get; }    

    public FishParentState(Poolable fish, Vehicle vehicle, LocomotionAnimator animator, Hunger hunger, WanderState.Stats wanderStats, ArriveState.Stats arriveStats)
    {
        // all layers
        StateMachine baseLayer = BaseLayer;
        StateMachine hungerTickLayer = AddLayer("Hunger Tick Layer");

        // all states
        var aliveState = new FishAliveState(vehicle, animator, hunger, wanderStats, arriveStats);
        var depleteHungerState = new DepleteHungerState(hunger);
        var dieState = new FishDieState(0.4f, vehicle, animator, fish);

        // all transitions
        baseLayer.AddAnyTransition(dieState, () => hunger.PercentValue <= 0.0f);

        // all defaults
        baseLayer.SetState(aliveState);
        hungerTickLayer.SetState(depleteHungerState);
        
        // reset
        Init = () => baseLayer.SetState(aliveState);        
    }
}

﻿using UnityEngine;

public class EatFoodState : TimedState
{
    Material Material { get; }
    Lerper<float> TailAmountLerper { get; }
    Lerper<float> TailFrequencyLerper { get; }

    float WiggleFrequency
    {
        get => Material.GetFloat(UniformIDs.WiggleFrequency);
        set => Material.SetFloat(UniformIDs.WiggleFrequency, value);
    }
    float WiggleAmount
    {
        get => Material.GetFloat(UniformIDs.WiggleAmount);
        set => Material.SetFloat(UniformIDs.WiggleAmount, value);
    }

    float HalfDuration => Duration * 0.5f;
    float halfTime;
    float originAmount, originSpeed;

    public EatFoodState(float duration, LocomotionAnimator animator)
        :
        base(duration)
    {
        Material = animator.Material;

        TailAmountLerper = new Lerper<float>(
            () => WiggleAmount,
            (a, b, t) => WiggleAmount = Mathf.LerpUnclamped(a, b, t))
        { Duration = HalfDuration };

        TailFrequencyLerper = new Lerper<float>(
            () => WiggleFrequency,
            (a, b, t) => WiggleFrequency = Mathf.LerpUnclamped(a, b, t))
        { Duration = HalfDuration };
    }

    public override void OnEnter()
    {
        base.OnEnter();

        originAmount = WiggleAmount;
        originSpeed = WiggleFrequency;

        halfTime = Time.time + HalfDuration;

        TailAmountLerper.Begin(0.420f);
        TailFrequencyLerper.Begin(0.69f);

        QuickSfx.Slurp();
    }

    public override void OnExit()
    {
        base.OnExit();
        WiggleFrequency = originSpeed;
        WiggleAmount = originAmount;
    }

    public override void Tick(in float deltaTime)
    {
        base.Tick(deltaTime);
        TailAmountLerper.TryUpdate();
        TailFrequencyLerper.TryUpdate();

        if (Time.time > halfTime)
        {
            halfTime = Time.time + HalfDuration;
            TailAmountLerper.Begin(originAmount);
            TailFrequencyLerper.Begin(originSpeed);
        }
    }
}

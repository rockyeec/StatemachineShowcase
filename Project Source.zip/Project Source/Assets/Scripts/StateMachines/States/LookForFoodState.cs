﻿using UnityEngine;
using System;

public class LookForFoodState : IState
{
    Func<Vector3> GetPosition { get; }
    Action<Food> SetWorm { get; }

    public LookForFoodState(Vehicle vehicle, Action<Food> setWorm)
    {
        SetWorm = setWorm;
        GetPosition = () => vehicle.Position;
    }

    public void OnEnter() { }
    public void OnExit() { }
    public void Tick(in float deltaTime)
        => SetWorm( FoodFinder.Get(GetPosition(), 2.0f) );
}

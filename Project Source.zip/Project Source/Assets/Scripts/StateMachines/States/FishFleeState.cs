﻿using UnityEngine;

public class FishFleeState : TimedState
{
    Vehicle Vehicle { get; }
    FleeState FleeState { get; }
    float FastSpeed { get; }

    public bool IsTap => Input.GetMouseButton(1) && (MouseWorldPosition - Vehicle.Position).IsShorterThan(2.5f);
    Vector3 MouseWorldPosition => CameraUtil.MouseWorldPosition;
    float originalSpeed;

    Vector3 fleeSource;

    public FishFleeState(Vehicle vehicle, LocomotionAnimator animator)
        :
        base(0.69f)
    {
        Vehicle = vehicle;
        FleeState = new FleeState(vehicle, animator);
        FastSpeed = vehicle.MaxSpeed * 4.20f;
    }

    public override void OnEnter()
    {
        FleeState.OnEnter();

        originalSpeed = Vehicle.MaxSpeed;
        //Vehicle.MaxSpeed *= 3.0f;

        base.OnEnter();
    }

    public override void OnExit()
    {
        Vehicle.MaxSpeed = originalSpeed;
        FleeState.OnExit();

        base.OnExit();
    }

    public override void Tick(in float deltaTime)
    {
        if (IsTap)
            UpdateFleeSource();

        Vehicle.Target = fleeSource;
        Vehicle.MaxSpeed = originalSpeed + Mathf.PingPong(T, 0.5f) * FastSpeed;

        FleeState.Tick(deltaTime);

        base.Tick(deltaTime);
    }

    void UpdateFleeSource()
    {
        base.OnEnter();
        fleeSource = MouseWorldPosition;
    }
}

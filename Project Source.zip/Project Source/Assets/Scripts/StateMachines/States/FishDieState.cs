﻿using UnityEngine;

public class FishDieState : TimedState
{
    Poolable Fish { get; }
    Vehicle Vehicle { get; }
    Material Material { get; }
    Lerper<float> TailAmountLerper { get; }
    Lerper<float> FlipYLerper { get; }
    Lerper<Quaternion> RotationLerper { get; }

    float FlipY
    {
        get => Material.GetFloat(UniformIDs.FlipY);
        set => Material.SetFloat(UniformIDs.FlipY, value);
    }
    float WiggleAmount
    {
        get => Material.GetFloat(UniformIDs.WiggleAmount);
        set => Material.SetFloat(UniformIDs.WiggleAmount, value);
    }

    float originAmount, originFlipY;

    public FishDieState(float duration, Vehicle vehicle, LocomotionAnimator animator, Poolable fish)
        :
        base(duration)
    {
        Vehicle = vehicle;
        Material = animator.Material;
        Fish = fish;

        TailAmountLerper = new Lerper<float>(
            () => WiggleAmount,
            (a, b, t) => WiggleAmount = Mathf.LerpUnclamped(a, b, t))
        { Duration = this.Duration };

        FlipYLerper = new Lerper<float>(
            () => FlipY,
            (a, b, t) => FlipY = Mathf.LerpUnclamped(a, b, t))
        { Duration = this.Duration };

        RotationLerper = new Lerper<Quaternion>(
            () => vehicle.Rotation,
            (a, b, t) => vehicle.Rotation = Quaternion.SlerpUnclamped(a, b, t))
        { Duration = this.Duration };
    }

    public override void OnEnter()
    {
        base.OnEnter();

        originAmount = WiggleAmount;
        originFlipY = FlipY;

        float flipYSign = Mathf.Sign(FlipY);

        TailAmountLerper.Begin(0.0f);
        FlipYLerper.Begin(-flipYSign);
        RotationLerper.Begin(
            flipYSign > 0.0f
            ? Quaternion.identity
            : Quaternion.Euler(0.0f, 0.0f, 180.0f));
    }

    public override void OnExit()
    {
        base.OnExit();
        FlipY = originFlipY;
        WiggleAmount = originAmount;
    }

    public override void Tick(in float deltaTime)
    {
        base.Tick(deltaTime);
        TailAmountLerper.TryUpdate();
        FlipYLerper.TryUpdate();
        RotationLerper.TryUpdate();

        Vehicle.Position += 0.420f * Vector3.up * deltaTime;
        if (Vehicle.Position.y > CameraUtil.WorldRect.yMax)
            ObjectPool.PoolIn(Fish);
    }
}
﻿using UnityEngine;

public class FastArriveState : IState
{
    Vehicle Vehicle { get; }
    PursuitState ArriveState { get; }

    float originalSpeed;

    public FastArriveState(Vehicle vehicle, LocomotionAnimator animator/*, ArriveState.Stats arriveStats*/)
    {
        Vehicle = vehicle;
        ArriveState = new PursuitState(vehicle, animator);
        originalSpeed = vehicle.MaxSpeed;
    }

    public void OnEnter()
    {
        originalSpeed = Vehicle.MaxSpeed;
        Vehicle.MaxSpeed *= 6.9f;
        ArriveState.OnEnter();
    }

    public void OnExit()
    {
        Vehicle.MaxSpeed = originalSpeed;
        ArriveState.OnExit();
    }

    public void Tick(in float deltaTime)
        => ArriveState.Tick(deltaTime);
}

﻿public class DepleteHungerState : IState
{
    Hunger Hunger { get; }

    public DepleteHungerState(Hunger hunger)
        => Hunger = hunger;
    public void OnEnter() { }

    public void OnExit() { }

    public void Tick(in float deltaTime)
        => Hunger.Tick(deltaTime);
}

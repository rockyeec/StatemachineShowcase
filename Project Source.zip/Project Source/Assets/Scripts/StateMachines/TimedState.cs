﻿using UnityEngine;

public class TimedState : IState
{
    public bool IsFinish => Time.time > FinishTime;
    protected float Duration { get; }
    protected float FinishTime { get; private set; }
    protected float T => 1.0f - (FinishTime - Time.time) / Duration;

    public TimedState(float duration)
        => Duration = duration;
    public virtual void OnEnter()
        => FinishTime = Time.time + Duration;
    public virtual void OnExit() { }
    public virtual void Tick(in float deltaTime) { }
}

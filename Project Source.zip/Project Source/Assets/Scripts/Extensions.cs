using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Random = UnityEngine.Random;

public static class Extensions
{
    public static Vector3 With(this Vector3 v, float? x = null, float? y = null, float? z = null)
        => new Vector3(x ?? v.x, y ?? v.y, z ?? v.z);
    public static bool IsLongerThan(this Vector3 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector3 v, float length)
        => v.sqrMagnitude < length * length;
    public static bool IsLongerThan(this Vector2 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector2 v, float length)
        => v.sqrMagnitude < length * length;

    public static Collider2D GetNearest(this List<Collider2D> colliders, Vector3 position)
        => colliders.OrderBy(c => (position - c.transform.position).sqrMagnitude).FirstOrDefault();

    public static T GetRandom<T>(this List<T> thisList)
        => thisList[Random.Range(0, thisList.Count)];    
    public static T GetRandom<T>(this T[] thisList)
        => thisList[Random.Range(0, thisList.Length)];

    public static float SmootherStep(this float t)
        => t * t * t * (t * (6.0f * t - 15.0f) + 10.0f);

    public static void Increment(this ref int i, int max)
        => i = (i + 1) % max;
    public static void Decrement(this ref int i, int max)
    {
        --i;
        if (i < 0) i = max - 1;
    }
}

using UnityEngine;
using System;

[Serializable]
public class Vehicle
{ 
    public Vector3 Target { get; set; }
    public float Mass => mass;
    public float MaxForce => maxForce;
    public float MaxSpeed { get => maxSpeed; set => maxSpeed = value; }
    public Vector3 Position { get => GetPosition(); set => SetPosition(value); }
    public Vector3 Velocity { get; set; }
    public Quaternion Rotation { get => GetRotation(); set => SetRotation(value); }
    
    [SerializeField] float mass = 1.0f;
    [SerializeField] float maxForce = 1.0f;
    [SerializeField] float maxSpeed = 1.0f;    

    Func<Vector3> GetPosition { get; set; }
    Action<Vector3> SetPosition { get; set; }
    Func<Quaternion> GetRotation { get; set; }
    Action<Quaternion> SetRotation { get; set; }

    public void Init(Func<Vector3> getPosition, Action<Vector3> setPosition, Func<Quaternion> getRotation, Action<Quaternion> setRotation)
    {
        GetPosition = getPosition;
        SetPosition = setPosition;
        GetRotation = getRotation;
        SetRotation = setRotation;
    }
    public void Init(Transform transform)
    {
        Init(() => transform.position, p => transform.position = p, () => transform.rotation, r => transform.rotation = r);
    }
}

public static class VehicleUtility
{
    public static Vector3 GetSteeringForce(Vehicle vehicle, Vector3 desiredVelocity)
    {
        float maxForce = Mathf.Max(vehicle.MaxForce, 0.0f);
        Vector3 steering = desiredVelocity - vehicle.Velocity;
        return Vector3.ClampMagnitude(steering, maxForce);
    }
    public static void UpdateFromSteeringForce(Vehicle vehicle, Vector3 steeringForce, in float deltaTime)
    {
        float mass = Mathf.Max(vehicle.Mass, 1e-2f);
        float maxSpeed = Mathf.Max(vehicle.MaxSpeed, 0.0f);

        Vector3 acceleration = steeringForce / mass;
        vehicle.Velocity = Vector3.ClampMagnitude(vehicle.Velocity + acceleration, maxSpeed);
        vehicle.Position += vehicle.Velocity * deltaTime;

        if (vehicle.Velocity != Vector3.zero)
            vehicle.Rotation = Quaternion.Euler( 0.0f, 0.0f, Mathf.Atan2(vehicle.Velocity.x, -vehicle.Velocity.y) * Mathf.Rad2Deg + 90.0f );
    }
    public static void CheckBounds(Vehicle vehicle)
    {
        Rect world = CameraUtil.WorldRect;

        if (vehicle.Position.x < world.xMin) { vehicle.Position = vehicle.Position.With(x: world.xMin); vehicle.Rotation = Quaternion.Euler(0f,0f,180f); vehicle.Target = 2f * vehicle.Position - vehicle.Target; vehicle.Velocity = Vector3.zero; }
        if (vehicle.Position.x > world.xMax) { vehicle.Position = vehicle.Position.With(x: world.xMax); vehicle.Rotation = Quaternion.Euler(0f,0f,  0f); vehicle.Target = 2f * vehicle.Position - vehicle.Target; vehicle.Velocity = Vector3.zero; }
        if (vehicle.Position.y < world.yMin) { vehicle.Position = vehicle.Position.With(y: world.yMin); vehicle.Rotation = Quaternion.Euler(0f,0f,-90f); vehicle.Target = 2f * vehicle.Position - vehicle.Target; vehicle.Velocity = Vector3.zero; }
        if (vehicle.Position.y > world.yMax) { vehicle.Position = vehicle.Position.With(y: world.yMax); vehicle.Rotation = Quaternion.Euler(0f,0f, 90f); vehicle.Target = 2f * vehicle.Position - vehicle.Target; vehicle.Velocity = Vector3.zero; }
    }
}

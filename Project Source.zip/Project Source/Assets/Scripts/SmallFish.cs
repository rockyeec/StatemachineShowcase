using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class SmallFish : MonoBehaviour
{
    readonly StateMachine stateMachine = new StateMachine();

    [SerializeField] Vehicle vehicle = null;
    [SerializeField] WanderState.Stats wanderStats = null;

    private void Awake()
    {
        vehicle.Init(transform);

        var animator = new LocomotionAnimator(vehicle, GetComponent<SpriteRenderer>().material);
        var flockState = new FlockState(vehicle, animator, wanderStats);
        var fishFleeState = new FishFleeState(vehicle, animator);

        stateMachine.AddTransition(fishFleeState, flockState, () => fishFleeState.IsFinish);
        stateMachine.AddTransition(flockState, fishFleeState, () => fishFleeState.IsTap);
        stateMachine.SetState(flockState);
    }
    private void Update()
    {
        stateMachine.Tick(Time.deltaTime);
    }
}
